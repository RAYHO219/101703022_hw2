//
//  ViewController.swift
//  calculator
//
//  Created by valerie's mac on 2017/4/13.
//  Copyright © 2017年 RAY. All rights reserved.
//

import UIKit



class ViewController: UIViewController {

    var screenNumber : Double = 0
    var previousNumber : Double = 0
    var performmainmath = false
    var operation = 0
    
    @IBOutlet weak var displaylabel: UILabel!

    

    @IBAction func number(_ sender: UIButton) {
        
        if performmainmath == true {
            displaylabel.text = String(sender.tag-1000)
           screenNumber = Double(displaylabel.text!)!
            performmainmath =  false
       }
        else {
        displaylabel.text = displaylabel.text! + String(sender.tag-1000)
        screenNumber = Double(displaylabel.text!)!
        }
}


    @IBAction func calculate(_ sender: UIButton) {
     
        if displaylabel.text != "" && displaylabel.text != "+" && displaylabel.text != "x" && displaylabel.text != "-" && displaylabel.text != "/" && sender.tag != 15 && sender.tag != 16  {
            previousNumber = Double(displaylabel.text!)!
            
            if sender.tag == 11 {
                
                displaylabel.text = "+"
           } //plus
            else if sender.tag == 12 {
                displaylabel.text = "-"
            }//minus
            else if sender.tag == 13 {
                displaylabel.text = "x"
            }//multipy
            else if sender.tag == 14 {
                displaylabel.text = "/"
            }//divide
            else if sender.tag == 17 {
                displaylabel.text = "^"
            }
            else if sender.tag == 18 {
                displaylabel.text = "ⁿ√"
            }
            operation = sender.tag
            
          performmainmath = true
        }
        
            else if sender.tag == 16 {
            
             if operation == 11 {
                displaylabel.text = String(previousNumber + screenNumber)
                    
                }
              else  if operation == 12 {
                
                    displaylabel.text = String(previousNumber - screenNumber)
                }
               else if operation == 13 {
                
                displaylabel.text = String(previousNumber * screenNumber)
                    
                }
              else  if operation == 14 {
                
                displaylabel.text = String(previousNumber / screenNumber)
                    
                }
             else if operation == 17 {
                displaylabel.text = String(pow(previousNumber, screenNumber))
            }
             else if operation == 18 {
                let screenNumber2 = (1 / screenNumber )
                displaylabel.text = String(pow(previousNumber, screenNumber2))
            }
            //每次運算後要先按等於再接後面的運算！！
            
        }
             else if sender.tag == 15 {
                displaylabel.text = ""
                previousNumber = 0
                screenNumber = 0
                operation = 0
            }
        
        }
        
    @IBAction func dot(_ sender: UIButton) {
        
        
        let currentText = self.displaylabel.text ?? "0"

        guard !currentText.contains(".") else {
            return
        }
        self.displaylabel.text = currentText + "."
    

    }
    
    @IBAction func percent(_ sender: UIButton) {
        var answer : Double = 0
        
        if displaylabel.text != "" && displaylabel.text != "+" && displaylabel.text != "-" && displaylabel.text != "x" && displaylabel.text != "/" && displaylabel.text != "^" && displaylabel.text != "ⁿ√" {
            
          answer =  Double(displaylabel.text!)!
         
            displaylabel.text = String( answer / 100)
  
    
        }
    }

    @IBAction func sqrt(_ sender: UIButton) {
        var answer2 : Double = 0
        
        if displaylabel.text != "" && displaylabel.text != "+" && displaylabel.text != "-" && displaylabel.text != "x" && displaylabel.text != "/" && displaylabel.text != "ⁿ√" && displaylabel.text != "^"{
            
            answer2 =  Double(displaylabel.text!)!
            
            displaylabel.text = String(Darwin.sqrt(answer2))
            
            
            
        }
        
    }
    
    
    
    @IBAction func square(_ sender: UIButton) {
        var answer3 : Double = 0
        
        if displaylabel.text != "" && displaylabel.text != "+" && displaylabel.text != "-" && displaylabel.text != "x" && displaylabel.text != "/" && displaylabel.text != "^" && displaylabel.text != "ⁿ√"{
            
            answer3 =  Double(displaylabel.text!)!
            
            displaylabel.text = String(answer3 * answer3)
            
    }
    
    
    }
    
    @IBAction func log(_ sender: UIButton) {
        var answer5 : Double = 0
        
        if displaylabel.text != "" && displaylabel.text != "+" && displaylabel.text != "-" && displaylabel.text != "x" && displaylabel.text != "/" && displaylabel.text != "^" && displaylabel.text != "ⁿ√"{
            
            answer5 =  Double(displaylabel.text!)!
            
            displaylabel.text = String(Darwin.log10(answer5))
            
        }

        
        
        
    }
    
    @IBAction func pi(_ sender: UIButton) {
        var answer4 : Double = 0
         if displaylabel.text == "" {
            displaylabel.text = String(Double.pi)
         }
        
        else if displaylabel.text  != "+" && displaylabel.text != "-" && displaylabel.text != "x" && displaylabel.text != "/" && displaylabel.text != "^" && displaylabel.text != "ⁿ√"{
            
            answer4 =  Double(displaylabel.text!)!
            
            displaylabel.text = String(answer4 * Double.pi)
     }
}
    @IBAction func plusandminus(_ sender: UIButton) {
        if  displaylabel.text != "+" && displaylabel.text != "-" && displaylabel.text != "x" && displaylabel.text != "/" && displaylabel.text != "^" && displaylabel.text != "ⁿ√"{
        let currentText = self.displaylabel.text ?? "0"
        
        guard !currentText.contains("-") else {
            var includminus :Double = 0
            includminus = Double(displaylabel.text!)!
            displaylabel.text = String(includminus + (includminus * -2))
            
            return
        }
        self.displaylabel.text = "-" + currentText
        
        }

       
    
    
    
    
    }
    @IBAction func exp(_ sender: UIButton) {
        var answer5 : Double = 0
        
        if displaylabel.text != "" && displaylabel.text != "+" && displaylabel.text != "-" && displaylabel.text != "x" && displaylabel.text != "/" && displaylabel.text != "^" && displaylabel.text != "ⁿ√"{
            
            answer5 =  Double(displaylabel.text!)!
            
            displaylabel.text = String(Darwin.exp(answer5))
            
        }

        
        
    }
    
}


